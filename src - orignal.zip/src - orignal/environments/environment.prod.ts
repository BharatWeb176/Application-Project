export const environment = {
  firebase: {
    projectId: 'happypaws-621b1',
    appId: '1:957404999094:web:38ded4e2bb534d0ace2517',
    storageBucket: 'happypaws-621b1.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyChst9Uo1po9_nMuuK4rN21r5MRbfZlRus',
    authDomain: 'happypaws-621b1.firebaseapp.com',
    messagingSenderId: '957404999094',
  },
  production: false,
};
